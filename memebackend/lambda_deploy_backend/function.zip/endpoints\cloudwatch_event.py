def cloudwatch_event_handler(event):
    pass