# -*- coding: utf-8 -*-

from .timeout_decorator import timeout
from .timeout_decorator import TimeoutError

__title__ = 'timeout_decorator'
__version__ = '0.5.0'
